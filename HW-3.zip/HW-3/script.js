const animalCards = document.querySelectorAll(".animal-card");
const musicButton = document.getElementById("musicBtn");
const resetButton = document.getElementById("resetBtn");
const backgroundMusic = document.getElementById("backgroundMusic");
const counterText = document.getElementById("counterText");
const message = document.getElementById("message");

let playCounter = Number(localStorage.getItem("myJungleCounter")) || 0;
counterText.textContent = `מספר קולות החיות שהושמעו: ${playCounter}`;

// אלמנט שלא למדנו בכיתה: localStorage
// localStorage שומר מידע בתוך הדפדפן גם אחרי רענון העמוד.
// באתר הזה הוא שומר כמה פעמים המשתמש השמיע קולות של חיות.
function updateCounter() {
    playCounter++;
    localStorage.setItem("myJungleCounter", playCounter);
    counterText.textContent = `מספר קולות החיות שהושמעו: ${playCounter}`;
}

function showMessage(text) {
    message.textContent = text;
}

function markActiveCard(card) {
    card.classList.add("active");

    setTimeout(() => {
        card.classList.remove("active");
    }, 450);
}

function playSoundById(soundId) {
    const sound = document.getElementById(soundId);

    if (!sound) {
        showMessage("לא נמצא קובץ שמע מתאים לחיה הזאת.");
        return;
    }

    sound.pause();
    sound.currentTime = 0;
    sound.volume = 0.9;

    sound.play()
        .then(() => {
            updateCounter();
            showMessage("קול החיה הופעל בהצלחה ✅");
        })
        .catch(() => {
            showMessage("הדפדפן חסם שמע. לחצו פעם אחת על המסך ואז נסו שוב.");
        });
}

function activateCard(card) {
    playSoundById(card.dataset.sound);
    markActiveCard(card);
}

animalCards.forEach((card) => {
    card.addEventListener("click", () => activateCard(card));

    card.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
            activateCard(card);
        }
    });
});

document.addEventListener("keydown", (event) => {
    const pressedCode = event.code;
    const pressedKey = event.key.toLowerCase();

    const matchingCard = Array.from(animalCards).find((card) => {
        return card.dataset.code === pressedCode || card.dataset.key === pressedKey;
    });

    if (matchingCard) {
        activateCard(matchingCard);
    }
});

musicButton.addEventListener("click", () => {
    if (backgroundMusic.paused) {
        backgroundMusic.volume = 0.25;
        backgroundMusic.play()
            .then(() => {
                musicButton.textContent = "עצור מוזיקת רקע";
                showMessage("מוזיקת הרקע של הג׳ונגל הופעלה 🎵");
            })
            .catch(() => {
                showMessage("הדפדפן חסם את מוזיקת הרקע. נסו ללחוץ שוב.");
            });
    } else {
        backgroundMusic.pause();
        musicButton.textContent = "הפעל מוזיקת רקע";
        showMessage("מוזיקת הרקע נעצרה.");
    }
});

resetButton.addEventListener("click", () => {
    playCounter = 0;
    localStorage.setItem("myJungleCounter", playCounter);
    counterText.textContent = `מספר קולות החיות שהושמעו: ${playCounter}`;
    showMessage("המונה אופס.");
});

window.addEventListener("load", () => {
    backgroundMusic.volume = 0.25;

    // הערה חשובה: רוב הדפדפנים לא מאפשרים הפעלה אוטומטית של שמע לפני פעולה של המשתמש.
    // לכן יש כפתור שמפעיל את מוזיקת הרקע בצורה תקינה.
    showMessage("לחצו על חיה, על מקש במקלדת, או על כפתור מוזיקת הרקע.");
});
